

function calculate() {
  var num1 = parseFloat(document.getElementById("num1").value);
  var num2 = parseFloat(document.getElementById("num2").value);
  var operator = document.getElementById("operator").value;
  var result;

  switch (operator) {
      case "+":
          result = num1 + num2;
          break;
      case "-":
          result = num1 - num2;
          break;
      case "*":
          result = num1 * num2;
          break;
      case "/":
          result = num1 / num2;
          break;
      default:
          result = "Invalid operator";
  }

  document.getElementById("result").textContent = "Result: " + result;
}


function appendToDisplay(value) {
document.getElementById("display").value += value;
}

function clearDisplay() {
document.getElementById("display").value = "";
}

function calculate() {
var expression = document.getElementById("display").value;
var result = eval(expression);
document.getElementById("display").value = expression + "=" + result;
}

function power() {
var base = parseFloat(document.getElementById("display").value);
var exponent = prompt("Enter the exponent:");
var result = Math.pow(base, exponent);
document.getElementById("display").value = base + "^" + exponent + "=" + result;
}

function sqrt() {
var value = parseFloat(document.getElementById("display").value);
var result = Math.sqrt(value);
document.getElementById("display").value = "√" + value + "=" + result;
}

function log() {
var value = parseFloat(document.getElementById("display").value);
var result = Math.log10(value);
document.getElementById("display").value = "log(" + value + ")=" + result;
}

function exp() {
var value = parseFloat(document.getElementById("display").value);
var result = Math.exp(value);
document.getElementById("display").value = "exp(" + value + ")=" + result;
}

function sin() {
var value = parseFloat(document.getElementById("display").value);
var result = Math.sin(value);
document.getElementById("display").value = "sin(" + value + ")=" + result;
}

function cos() {
var value = parseFloat(document.getElementById("display").value);
var result = Math.cos(value);
document.getElementById("display").value = "cos(" + value + ")=" + result;
}

function tan() {
var value = parseFloat(document.getElementById("display").value);
var result = Math.tan(value);
document.getElementById("display").value = "tan(" + value + ")=" + result;
}
