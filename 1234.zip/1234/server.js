const express = require('express');
const cors = require('cors');
const mysql = require('mysql');

const app = express();
const port = 3060;

app.use(cors()); // 允许所有跨域请求
app.use(express.json());

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'abc22',
  password: '327166',
  database: 'index1'
});

// 获取历史数据
app.get('/fetchHistory1Data', (req, res) => {
  connection.query('SELECT * FROM history1', (error, results) => {
    if (error) {
      console.error('查询失败: ' + error.stack);
      res.status(500).send('Internal Server Error');
      return;
    }

    res.json(results);
  });
});

// 获取实时数据
app.get('/realtimeHistory1Data', (req, res) => {
  connection.query('SELECT * FROM history1', (error, results) => {
    if (error) {
      console.error('查询失败: ' + error.stack);
      res.status(500).send('Internal Server Error');
      return;
    }

    res.json(results);
  });
});

// 添加数字到数据库
app.post('/addNumbers', (req, res) => {
  const { numbers } = req.body;

  if (!Array.isArray(numbers) || numbers.length !== 2) {
    res.status(400).send('Bad Request');
    return;
  }

  const sql = 'INSERT INTO history1 (formula, result) VALUES (?, ?)';
  connection.query(sql, numbers, (error, results) => {
    if (error) {
      console.error('添加数字失败: ' + error.stack);
      res.status(500).send('Internal Server Error');
      return;
    }

    res.sendStatus(200);
  });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
